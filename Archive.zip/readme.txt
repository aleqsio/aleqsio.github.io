Przesyłam projekt ze zbiorów rozmytych, 
zrobiony z uzyciem biblioteki https://github.com/marcolanaro/JS-Fuzzy

Dokumentacja oraz applet znajduje się na stronie https://aleqsio.github.io/

Aleksander Mikucki